package com.mcy.springbootshiro.constants;

/**
 * 常量类
 * */
public class Constants {


    public final static String USER_NOT_FOUNT = "用户名不存在";
    public final static String USER_FAULT = "密码错误";

    public static final String redisHost = "127.0.0.1";


}
