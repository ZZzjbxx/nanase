package com.mcy.springbootshiro.repository;


import com.mcy.springbootshiro.entity.yonghu;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface yonghuRepository extends JpaRepository<yonghu, Integer>, JpaSpecificationExecutor<yonghu> {
    List<yonghu> findAll();

    yonghu deleteById(int id);

    yonghu save(yonghu yh);

    yonghu findById(int id);


}
