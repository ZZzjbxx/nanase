package com.mcy.springbootshiro.utils;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import com.mcy.springbootshiro.entity.SysUser;
import org.apache.shiro.crypto.hash.SimpleHash;
import org.apache.shiro.util.ByteSource;
import org.springframework.util.StringUtils;



public class MD5Util {

    public static String md5(SysUser yh,String password) {
        String hashAlgorithName = "MD5";
        //加密次数
        int hashIterations = 1024;
        ByteSource credentialsSalt = ByteSource.Util.bytes(yh.getUsername());
        String obj = new SimpleHash(hashAlgorithName, password, credentialsSalt, hashIterations).toHex();
        System.out.println(obj);
        return obj;
    }

    /**
     * 对字符串进行Md5加密
     *
     * @param input 原文
     * @param salt 随机数
     * @return string
     */


}
