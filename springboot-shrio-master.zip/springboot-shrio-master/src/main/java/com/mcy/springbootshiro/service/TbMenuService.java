package com.mcy.springbootshiro.service;

import org.springframework.stereotype.Service;

@Service
public class TbMenuService {

}
