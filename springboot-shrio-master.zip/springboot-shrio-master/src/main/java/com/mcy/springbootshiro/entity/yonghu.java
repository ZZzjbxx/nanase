package com.mcy.springbootshiro.entity;


import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.io.Serializable;

@Entity
@Data
public class yonghu implements Serializable {


    @Id
    @GeneratedValue
    private Integer id;
    private String name;
    private String tel;
    private String addr;

}
