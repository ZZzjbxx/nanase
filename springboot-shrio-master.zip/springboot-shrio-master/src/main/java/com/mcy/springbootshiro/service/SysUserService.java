package com.mcy.springbootshiro.service;

import com.mcy.springbootshiro.entity.SysUser;
import com.mcy.springbootshiro.repository.SysUserRepository;
import com.mcy.springbootshiro.utils.MD5Util;
import org.apache.shiro.crypto.hash.SimpleHash;
import org.apache.shiro.util.ByteSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

@Service
public class SysUserService {

    @Autowired
    private SysUserRepository userRepository;

    public SysUser findByUsername(String username) {
        return userRepository.findByUsername(username);
    }

    public void save(SysUser user) {
        userRepository.save(user);
    }


    public void updatePwd(SysUser user, String oldPassword, String password1, String password2) {
        Assert.notNull(user, "用户不能为空");
        Assert.notNull(oldPassword, "原始密码不能为空");
        Assert.notNull(password1, "新密码不能为空");
        Assert.notNull(password2, "重复密码不能为空");

        SysUser dbUser = userRepository.findByUsername(user.getUsername());
        Assert.notNull(dbUser, "用户不存在");

        Assert.isTrue(user.getPassword().equals(MD5Util.md5(user,oldPassword)), "原始密码不正确");;
        Assert.isTrue(password1.equals(password2), "两次密码不一致");
        dbUser.setPassword(MD5Util.md5(user,password1));
        userRepository.saveAndFlush(dbUser);

    }


}
