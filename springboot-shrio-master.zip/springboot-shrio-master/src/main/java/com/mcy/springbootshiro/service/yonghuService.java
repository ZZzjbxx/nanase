package com.mcy.springbootshiro.service;

import com.mcy.springbootshiro.entity.SysUser;
import com.mcy.springbootshiro.entity.yonghu;
import com.mcy.springbootshiro.repository.SysUserRepository;
import com.mcy.springbootshiro.repository.yonghuRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.ListOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.stereotype.Service;
import redis.clients.jedis.Jedis;

import javax.annotation.Resource;
import java.util.List;
import java.util.Optional;

@Service
public class yonghuService {

    @Autowired
    private yonghuRepository yonghuRepository;

    @Resource
    RedisTemplate redisTemplate;

    public List<yonghu> list() {
        String key = "yonghu";
        ListOperations<String,yonghu> operations = redisTemplate.opsForList();

        if (redisTemplate.hasKey(key)) {
            return operations.range(key, 0, -1);
        } else {
            List<yonghu> list = yonghuRepository.findAll();
            operations.rightPushAll(key, list);  //向集合右边输入list，由小到大展示
            return list;
        }
    }

    public yonghu delyonghu(int id){
        yonghu yh=new yonghu();
        Jedis jedis;
        String key = "yonghu_" + id;
        String key1 = "yonghu";
        ListOperations<String,yonghu> operations = redisTemplate.opsForList();
        if (redisTemplate.hasKey(key)) {
            //删除对应缓存
            redisTemplate.delete(key);
        }
        yh=yonghuRepository.findById(id);
        operations.remove(key1,1,yh);
        yonghuRepository.deleteById(id);
        return yh;
    }

    public void save(yonghu yh) {
        yonghuRepository.save(yh);
        String key = "yonghu_" + yh.getId();
        ValueOperations<String, yonghu> operations = redisTemplate.opsForValue();
        operations.set(key, yh);
        String key1 = "yonghu";
        ListOperations<String, yonghu> operations1 = redisTemplate.opsForList();
        operations1.rightPush(key1, yh);  //向集合右边输入list，由小到大展示

    }

    public yonghu findById(int id) {
        String key = "yonghu_" + id;
        ValueOperations<String, yonghu> operations = redisTemplate.opsForValue();
        if (redisTemplate.hasKey(key)) {
            return operations.get(key);
        } else {
            //得到学生对象
            yonghu yh = yonghuRepository.findById(id);
            ;
            //添加到缓存
            operations.set(key, yh);
            return yh;
        }

    }
}

