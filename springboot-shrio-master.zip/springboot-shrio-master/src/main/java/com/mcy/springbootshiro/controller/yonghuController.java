package com.mcy.springbootshiro.controller;

import com.mcy.springbootshiro.entity.SysUser;
import com.mcy.springbootshiro.entity.yonghu;
import com.mcy.springbootshiro.service.yonghuService;
import lombok.Data;
import org.apache.shiro.crypto.hash.SimpleHash;
import org.apache.shiro.util.ByteSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
public class yonghuController {
    @Autowired
    private yonghuService yongService;


    @GetMapping("/user")
    //show
    public String Show(Model model) {
        List<yonghu> yonghu = yongService.list();
        model.addAttribute("yonghu", yonghu);
        return "yonghu";
    }

    @DeleteMapping("/yonghu/delyonghu")
    //delUser
    public String delyonghu(Integer id){
        yongService.delyonghu(id);
        return "redirect:/user";

    }


    @PostMapping("/yonghu/create")
    public String create(String name,String addr,String tel){
       yonghu yh=new yonghu();
        yh.setAddr(addr);
        yh.setName(name);
        yh.setTel(tel);
        yongService.save(yh);
        return "redirect:/mian";
    }


    @GetMapping("/yonghu/id")
    //show
    public String findById(int id1,Model model) {
        model.addAttribute("yonghu", yongService.findById(id1));
        return "yonghu";
    }

}
